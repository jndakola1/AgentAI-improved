# AgentAI

AgentAI is the smart, reliable assistant for business professionals. Instead of digging through menus, you simply chat with your AI agent to find new business leads, create follow-up tasks, and get instant data analysis. It's like having a personal data analyst available 24/7 to help you close deals faster. We've engineered it with structured logging and robust error handling, ensuring high system reliability so you can trust AgentAI for your most critical workflows.

## Getting Started

### Prerequisites

* Node.js
* An AWS account with access to Bedrock

### Installation

1. Clone the repository:
   ```sh
   git clone <https://github.com/jndakola1/AgentAI-improved
   ```
2. Install the dependencies:
   ```sh
   npm install
   ```
3. Create a `.env` file in the root of the project and add the following environment variables:
   ```env
   AWS_REGION=<your-aws-region>
   AWS_AGENT_ID=<your-aws-agent-id>
   AWS_AGENT_ALIAS_ID=<your-aws-agent-alias-id>
   AWS_ACCESS_KEY_ID=<your-access-key-id>
   AWS_SECRET_ACCESS_KEY=<your-secret-access-key>
   PORT=8080
   ```
4. Start the server locally:
   ```sh
   npm start
   ```

   (or for live reload during development: `npm run dev`)

## Usage

Once the server is running, you can interact with the chatbot through the web interface. You can also send POST requests to the `/api/chat` endpoint with a JSON body like this:

```json
{
  "message": "Your message here"
}
```

### Lambda invoke

Send a POST request to `/api/lambda-invoke` with this shape:

```json
{
  "functionName": "my-lambda-function",
  "payload": { "key": "value" }
}
```

`functionName` can also be configured via `AWS_LAMBDA_FUNCTION_NAME` in `.env`.

# AgentAI


## Amplify deployment

This project is prepared for AWS Amplify Hosting with Express compute output.

### Required environment variables
Set these in Amplify Hosting before deployment:

- `AWS_REGION`
- `AWS_AGENT_ID`
- `AWS_AGENT_ALIAS_ID`
- `LAMBDA_FUNCTION_NAME` (optional)
- `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` only if your runtime truly requires long-lived IAM keys. Prefer an attached IAM role where possible.

### Notes
- Use a root `.env` file for local development.
- `npm run build` generates the `.amplify-hosting` bundle used by Amplify.
- Do not commit `node_modules` or real secret files.

import fs from 'fs';
import path from 'path';

const root = process.cwd();
const out = path.join(root, '.amplify-hosting');
const compute = path.join(out, 'compute', 'default');
const staticDir = path.join(out, 'static');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(compute, { recursive: true });
fs.mkdirSync(staticDir, { recursive: true });

copyDir(path.join(root, 'src'), path.join(compute, 'src'), ['.env']);
copyFileIfExists(path.join(root, 'package.json'), path.join(compute, 'package.json'));
copyFileIfExists(path.join(root, 'package-lock.json'), path.join(compute, 'package-lock.json'));
copyFileIfExists(path.join(root, 'README.md'), path.join(compute, 'README.md'));

fs.writeFileSync(path.join(compute, 'server.js'), 'import "./src/index.js";\n', 'utf8');

const publicSrc = path.join(root, 'src', 'public');
if (fs.existsSync(publicSrc)) {
  copyDir(publicSrc, staticDir);
}

const manifest = {
  version: 1,
  routes: [
    { path: '/styles.css', target: { kind: 'Static' } },
    { path: '/*.*', target: { kind: 'Static' }, fallback: { kind: 'Compute', src: 'default' } },
    { path: '/*', target: { kind: 'Compute', src: 'default' } }
  ],
  computeResources: [
    { name: 'default', runtime: 'nodejs22.x', entrypoint: 'server.js' }
  ]
};

fs.writeFileSync(path.join(out, 'deploy-manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
console.log('Amplify bundle created in .amplify-hosting');

function copyFileIfExists(src, dest) {
  if (fs.existsSync(src)) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}
function copyDir(src, dest, exclude = []) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (exclude.includes(entry.name)) continue;
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(srcPath, destPath, exclude);
    else fs.copyFileSync(srcPath, destPath);
  }
}
